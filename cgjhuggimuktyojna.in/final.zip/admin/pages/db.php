<?php
// $host = 'arpitjain.co';
// $username = 'arpitjai_muskanj';
// $pass = 'Tech9000';
// $db = 'arpitjai_pradhanmantri';
$host = 'localhost';
$username = 'root';
$pass = '';
$db = 'naman';
$conn = new mysqli($host,$username,$pass,$db);
if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}
 function testdata($data){
	 $data = trim($data);
	 $data = stripslashes($data);
	 $data = htmlspecialchars($data);
	 return $data;
 }
?>