jquery.tabletoCSV
=================

In browser table to csv export

Installation
============

```
bower install tabletoCSV
```

Usage
=====

```
$("#export_table").tableToCSV();
```

Table structure
===============

- ```<caption>``` - used for filename (defaults to timestamp)
- ```<th>``` - used to create title
